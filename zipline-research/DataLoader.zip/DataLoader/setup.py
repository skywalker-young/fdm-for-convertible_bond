#!/usr/bin/env python
# -*- coding:utf-8 -*-

from distutils.core import setup


setup(
    name='DataLoader',
    version='0.0.1',
    packages=['DataLoader'],
    license='Creative Commons Attribution-Noncommercial-Share Alike license',
    description='BackTesting Data Loader',
    author='HanZhiQun',
    package_data={
        'DataLoader': ['*.csv'],
    }
)
