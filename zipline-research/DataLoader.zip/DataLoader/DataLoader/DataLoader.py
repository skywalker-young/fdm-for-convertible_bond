# -*- coding:utf-8 -*-
from __future__ import absolute_import

"""
用于加载回测数据到MongoDB
"""

__date__ = '2018-10-18'
__author__ = 'HanZhiQun'

import os
import logging
from datetime import datetime

import pymongo
import pymssql

from DataLoader.vtObject import Bar

logging.basicConfig(
    format='%(levelname)s:%(asctime)s:%(message)s',
    level=logging.DEBUG
)

base_path = os.path.dirname(__file__)


class BackTestingDataLoader(object):

    def __init__(self, host='', user='', password='', trade_code_table_path=None):
        """
        初始化连接
        :param host: sql server 数据库地址，端口
        :param user: 用户名
        :param password: 密码
        :param trade_code_table_path: 从指定目录中加载csv数据
        """
        self.connection = pymssql.connect(
            host=host,
            user=user,
            password=password,
        )
        self.cursor = self.connection.cursor()

        if trade_code_table_path is None:
            self.trade_code_table_path = os.path.join(base_path, 'trade_code_table.csv')
        else:
            self.trade_code_table_path = trade_code_table_path

        self.mongo = pymongo.MongoClient('localhost', 27017)

    @staticmethod
    def _get_table_name(exchange_code, trade_code, mode='Day'):
        """
        得到数据库中对应的表名
        :param trade_code:
        :param mode:
        :return:
        """
        return '{}.dbo.{}_{}_{}'.format(exchange_code, exchange_code, mode, trade_code)

    def _get_collection(self, db_name, trade_code):
        """
        连接mongodb数据库
        :param db_name: 数据库名
        :param trade_code: 集合名
        :return:
        """
        collection = self.mongo[db_name][trade_code]
        collection.ensure_index([('datetime', pymongo.ASCENDING)], unique=True)
        return collection

    def _insert_into_collection(self, trade_code, row, db_name='', collection=''):
        """
        将得到的数据插入到mongodb数据库中
        :param trade_code: 合约代码
        :param row: bar结构体的数据
        :param db_name: 数据库名
        :param collection: 集合名
        :return:
        """
        bar = Bar(
            symbol=trade_code,
            open=float(row[1]),
            high=float(row[2]),
            low=float(row[3]),
            close=float(row[4]),
            volume=int(row[5]),
            openInterest=int(row[6]),
            date_time=row[0]
        )
        if bar.low == 0 or bar.close == 0:
            logging.info('')
            return

        if not db_name:
            db_name = 'BackTest'

        if not collection:
            collection = trade_code

        collection = self._get_collection(db_name, collection)
        flt = {'datetime': bar.datetime}
        collection.update_one(flt, {'$set': bar.__dict__}, upsert=True)

    def load_day(self, exchange_code, trade_code, start_date='', end_date='', db_name='', collection=''):
        """
        加载日线数据
        """
        date_format = '%Y-%m-%d'
        try:
            start_date = datetime.strptime(start_date, date_format).strftime(date_format)
        except ValueError:
            raise ValueError('start_date format error, eg: 2018-10-01')

        try:
            end_date = datetime.strptime(end_date, date_format).strftime(date_format)
        except ValueError:
            raise ValueError('end_date format error, eg: 2018-10-01')

        table_name = self._get_table_name(exchange_code, trade_code)

        raw_sql = (
            "SELECT * FROM {table_name} WHERE Date >= '{start_date}' "
            "AND Date <= '{end_date}';"
        )
        sql = raw_sql.format(table_name=table_name, start_date=start_date, end_date=end_date, offset=0)
        logging.info(sql)
        self.cursor.execute(sql)
        row = self.cursor.fetchone()
        while row:
            logging.info(row)
            self._insert_into_collection(trade_code, row, db_name, collection)
            row = self.cursor.fetchone()

    def load_minute_thirty(self, trade_code, start_date='', end_date='', db_name='',
                           collection=''):
        """
        加载30分钟线数据
        """
        date_format = '%Y-%m-%d'
        try:
            start_date = datetime.strptime(start_date, date_format).strftime(
                date_format)
        except ValueError:
            raise ValueError('start_date format error, eg: 2018-10-01')

        try:
            end_date = datetime.strptime(end_date, date_format).strftime(
                date_format)
        except ValueError:
            raise ValueError('end_date format error, eg: 2018-10-01')

        table_name = self._get_table_name(trade_code, mode='Min30')

        raw_sql = (
            "SELECT * FROM {table_name} WHERE Date >= '{start_date}' "
            "AND Date <= '{end_date}';"
        )
        sql = raw_sql.format(table_name=table_name, start_date=start_date,
                             end_date=end_date, offset=0)
        logging.info(sql)
        self.cursor.execute(sql)
        row = self.cursor.fetchone()
        while row:
            logging.info(row)
            self._insert_into_collection(trade_code, row, db_name, collection)
            row = self.cursor.fetchone()

    def load_minute_one(self, trade_code, start_date='', end_date='', db_name='',
                        collection=''):
        """
        加载一分钟线数据
        """
        date_format = '%Y-%m-%d'
        try:
            start_date = datetime.strptime(start_date, date_format).strftime(
                date_format)
        except ValueError:
            raise ValueError('start_date format error, eg: 2018-10-01')

        try:
            end_date = datetime.strptime(end_date, date_format).strftime(
                date_format)
        except ValueError:
            raise ValueError('end_date format error, eg: 2018-10-01')

        table_name = self._get_table_name(trade_code, mode='Min01')

        raw_sql = (
            "SELECT * FROM {table_name} WHERE Date >= '{start_date}' "
            "AND Date <= '{end_date}';"
        )
        sql = raw_sql.format(table_name=table_name, start_date=start_date,
                             end_date=end_date, offset=0)
        logging.info(sql)
        self.cursor.execute(sql)
        row = self.cursor.fetchone()
        while row:
            logging.info(row)
            row = row[:5] + row[6:]
            # logging.debug(row)
            self._insert_into_collection(trade_code, row, db_name, collection)
            row = self.cursor.fetchone()

    def close(self):
        """
        关闭数据库连接
        :return:
        """
        self.connection.close()
        self.mongo.close()


if __name__ == '__main__':
    host = '222.73.103.198:2435'
    user = 'temp_net_test_r'
    passwd = 'Y&GVYUVg7rr64eedIUG5ed'
    symbol = 'IF1810'

    db_client = BackTestingDataLoader(host, user, passwd)
    # db_client.load_day(symbol, '2018-01-01', '2018-12-01')
    # db_client.load_minute_thirty(symbol, '2018-01-01', '2018-12-01')
    db_client.load_minute_one(symbol, '2018-01-01', '2018-12-01', 'VnTrader_1Min_Db', 'IF1810')
