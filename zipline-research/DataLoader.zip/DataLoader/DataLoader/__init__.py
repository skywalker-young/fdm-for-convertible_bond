# -*- coding:utf-8 -*-
from __future__ import absolute_import

from DataLoader.DataLoader import BackTestingDataLoader

host = '192.168.2.195'
user = 'hanzq'
password = 'infochannel'

data_loader = BackTestingDataLoader(host=host, user=user, password=password)

__all__ = (data_loader,)
