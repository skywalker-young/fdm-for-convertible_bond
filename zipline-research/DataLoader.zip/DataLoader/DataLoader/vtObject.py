# -*- coding:utf-8 -*-

from datetime import datetime


class Bar(object):
    """
    日线Bar
    """

    def __init__(self, symbol, open, high, low, close,
                 volume, openInterest, date_time):

        if not isinstance(date_time, datetime):
            raise ValueError('date_time should be datetime object.')

        self.vtSymbol = symbol
        self.symbol = symbol

        self.open = open
        self.high = high
        self.low = low
        self.close = close

        self.volume = volume
        self.openInterest = openInterest

        self.datetime = date_time.strftime('%Y-%m-%d %H:%M:%S')
        self.date = date_time.date().strftime('%Y%m%d')
        self.time = date_time.strftime('%H:%M:%S')
